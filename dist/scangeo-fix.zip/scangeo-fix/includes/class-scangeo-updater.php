<?php
/**
 * Comprueba en un repositorio de GitHub si hay una versión más reciente del
 * plugin que la instalada, y lo conecta con el sistema de actualizaciones
 * nativo de WordPress (el mismo que usan los plugins del repositorio
 * oficial): aparece en Plugins → "Hay una nueva versión disponible" con su
 * botón "Actualizar ahora", sin que el usuario tenga que hacerlo a mano.
 *
 * CÓMO FUNCIONA (ya configurado para este plugin):
 * El plugin descarga el .zip directamente desde /dist/scangeo-fix.zip
 * dentro de este mismo repositorio (usando el tag de cada versión), en vez
 * de depender de los "adjuntos" de un Release de GitHub. Esto permite
 * publicar una versión nueva subiendo el código y el .zip con un simple
 * "git push" más la creación del Release (ambos automatizables), sin
 * ningún paso manual en la web de GitHub.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ScanGEO_Updater {

	/** Cambia esto por "tu-usuario-de-github/tu-repositorio". */
	const REPO = 'JuanmaAranda/scangeo-fix';

	const CACHE_KEY       = 'scangeo_fixer_latest_release';
	const CACHE_KEY_ALL   = 'scangeo_fixer_all_releases';
	const CHECK_ERROR_KEY = 'scangeo_fixer_update_check_error';
	// Identificador definitivo: tanto la carpeta instalada como el ZIP son
	// scangeo-fix. Se conserva la ruta antigua solo para migrar instalaciones
	// que se actualizaron antes de este cambio.
	const PLUGIN_FILE        = 'scangeo-fix/scangeo-fixer.php';
	const LEGACY_PLUGIN_FILE = 'scangeo-fixer/scangeo-fixer.php';
	const SLUG               = 'scangeo-fix';

	private static $initialized = false;

	/** Igual que en ScanGEO_AI: fuerza este timeout por encima de lo que el hosting imponga vía 'http_request_timeout'. */
	const REQUEST_TIMEOUT = 20;

	/** Fragmentos de mensaje que identifican un fallo de red transitorio (no un fallo real de la API de GitHub). */
	const TRANSIENT_ERROR_PATTERNS = array(
		'cURL error 28',
		'cURL error 7',
		'cURL error 6',
		'cURL error 35',
		'Connection timed out',
		'Operation timed out',
		'Could not resolve host',
		'Connection reset',
	);

	public static function force_timeout( $seconds ) {
		return self::REQUEST_TIMEOUT;
	}

	/** Guarda el motivo del último fallo al comprobar actualizaciones, para poder explicarlo en el panel en vez de dejarlo en silencio. */
	private static function remember_check_error( $message ) {
		set_transient( self::CHECK_ERROR_KEY, $message, 15 * MINUTE_IN_SECONDS );
	}

	/** Motivo del último fallo al comprobar actualizaciones (vacío si la última comprobación fue bien). */
	public static function get_last_check_error() {
		$msg = get_transient( self::CHECK_ERROR_KEY );
		return $msg ? (string) $msg : '';
	}

	/**
	 * wp_remote_get() forzando REQUEST_TIMEOUT de verdad (algunos hostings
	 * enganchan 'http_request_timeout' para forzar un límite fijo, típicamente
	 * 10s, en todas las peticiones salientes de cualquier plugin) y
	 * reintentando una vez si el primer intento falla por un error de red
	 * transitorio. Sin esto, la comprobación de actualizaciones se queda
	 * "en blanco" (sin aviso y sin error visible) en cuanto el hosting corta
	 * la conexión hacia la API de GitHub.
	 */
	private static function remote_get_with_retry( $url, $args ) {
		add_filter( 'http_request_timeout', array( __CLASS__, 'force_timeout' ), PHP_INT_MAX );
		$response = wp_remote_get( $url, $args );
		if ( is_wp_error( $response ) ) {
			$msg = $response->get_error_message();
			foreach ( self::TRANSIENT_ERROR_PATTERNS as $pattern ) {
				if ( false !== stripos( $msg, $pattern ) ) {
					usleep( 800000 );
					$response = wp_remote_get( $url, $args );
					break;
				}
			}
		}
		remove_filter( 'http_request_timeout', array( __CLASS__, 'force_timeout' ), PHP_INT_MAX );
		return $response;
	}

	public static function init() {
		// Guarda de seguridad: si algo llegara a llamar a init() más de una
		// vez en la misma petición, evita registrar los filtros por
		// duplicado (causaría, por ejemplo, un "Ver detalles" repetido).
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		// Prioridad muy alta (PHP_INT_MAX): hay plugins de gestión de
		// actualizaciones (p. ej. los que auto-actualizan todo el sitio) que
		// también enganchan estos mismos filtros y pueden reconstruir o
		// limpiar el array 'response' quedándose solo con los plugins que
		// ellos reconocen. Si ellos se ejecutan después de nosotros, nuestra
		// entrada desaparece antes de llegar a la pantalla de Actualizaciones,
		// aunque get_latest_release() haya funcionado perfectamente (por eso
		// el aviso sí aparecía dentro del propio panel de scanGEO Fixer, pero
		// no en Escritorio > Actualizaciones). Ejecutándonos los últimos nos
		// aseguramos de que nuestra entrada sea la que queda.
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check_update' ), PHP_INT_MAX );
		// La pantalla nativa puede reutilizar un transient ya creado. Al leerlo,
		// añadimos también nuestra actualización para que coincida con el aviso.
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'check_update' ), PHP_INT_MAX );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 20, 3 );
		add_filter( 'upgrader_source_selection', array( __CLASS__, 'fix_folder_name' ), 10, 4 );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'row_meta' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'after_update' ), 10, 2 );
	}

	/**
	 * Añade el enlace "Ver detalles" en la fila del plugin (listado de
	 * Plugins), igual que hacen los plugins de WordPress.org. Abre el mismo
	 * modal (thickbox) usando la información que ya devuelve plugin_info()
	 * más arriba — no depende de estar en el repositorio oficial.
	 */
	public static function row_meta( $links, $file ) {
		if ( self::PLUGIN_FILE !== $file && self::LEGACY_PLUGIN_FILE !== $file ) {
			return $links;
		}
		// Evita añadir un segundo enlace idéntico si, por lo que sea
		// (otro plugin de gestión de actualizaciones, un filtro externo),
		// ya hay uno con el mismo texto en la fila.
		foreach ( $links as $existing ) {
			if ( false !== strpos( (string) $existing, 'open-plugin-details-modal' ) ) {
				return $links;
			}
		}
		$details_url = self_admin_url(
			'plugin-install.php?tab=plugin-information&plugin=' . self::SLUG . '&TB_iframe=true&width=600&height=550'
		);
		$links[] = '<a href="' . esc_url( $details_url ) . '" class="thickbox open-plugin-details-modal" aria-label="Más información sobre scanGEO Fixer">Ver detalles</a>';
		return $links;
	}

	/**
	 * Se ejecuta justo después de cualquier actualización de plugin. Limpia
	 * nuestra caché de GitHub y el transient de actualizaciones de
	 * WordPress para que, tras actualizar, no se quede colgado un aviso
	 * fantasma diciendo que hay una versión nueva cuando ya se acaba de
	 * instalar.
	 */
	public static function after_update( $upgrader_object, $hook_extra ) {
		if ( empty( $hook_extra['action'] ) || 'update' !== $hook_extra['action'] || empty( $hook_extra['type'] ) || 'plugin' !== $hook_extra['type'] ) {
			return;
		}
		// Actualización en bloque (checkboxes): $hook_extra['plugins'] es un array.
		// Actualización individual (el enlace "Actualízalo ahora" de un solo
		// plugin, que es el que se usa desde el aviso amarillo): WordPress
		// manda 'plugin' (singular) con un solo nombre, no 'plugins'. Había
		// que comprobar los dos casos; por eso nunca se limpiaba la caché.
		$plugins = array();
		if ( ! empty( $hook_extra['plugins'] ) ) {
			$plugins = (array) $hook_extra['plugins'];
		} elseif ( ! empty( $hook_extra['plugin'] ) ) {
			$plugins = array( $hook_extra['plugin'] );
		}
		if ( ! in_array( self::PLUGIN_FILE, $plugins, true ) && ! in_array( self::LEGACY_PLUGIN_FILE, $plugins, true ) ) {
			return;
		}
		delete_transient( self::CACHE_KEY );
		delete_transient( self::CACHE_KEY_ALL );
		delete_site_transient( 'update_plugins' );
	}

	/**
	 * Versión realmente instalada, leída directamente de la cabecera del
	 * archivo del plugin en disco (igual que hace el propio WordPress),
	 * en vez de la constante SCANGEO_FIXER_VERSION. La constante se define
	 * al ejecutar el PHP, y en hostings con OPcache configurado de forma
	 * agresiva puede seguir sirviendo el valor de la versión anterior
	 * durante un rato después de actualizar los archivos — leer el
	 * archivo directamente evita ese problema.
	 */
	public static function installed_version() {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		foreach ( array( self::PLUGIN_FILE, self::LEGACY_PLUGIN_FILE ) as $plugin_file ) {
			$path = WP_PLUGIN_DIR . '/' . $plugin_file;
			if ( file_exists( $path ) ) {
				$data = get_plugin_data( $path, false, false );
				if ( ! empty( $data['Version'] ) ) {
					return trim( (string) $data['Version'] );
				}
			}
		}
		return defined( 'SCANGEO_FIXER_VERSION' ) ? trim( (string) SCANGEO_FIXER_VERSION ) : '0';
	}

	/** Devuelve solo el número de versión más reciente (o '' si no se sabe), para mostrarlo en pantalla. */
	public static function get_latest_version() {
		$release = self::get_latest_release();
		return $release ? $release['version'] : '';
	}

	/** Consulta la API de GitHub (con caché de 6 horas) y devuelve los datos del último release. */
	private static function get_latest_release() {
		if ( false !== strpos( self::REPO, 'TU-USUARIO' ) ) {
			return false; // Todavía no se ha configurado el repositorio real.
		}
		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached ) {
			return $cached ? $cached : false;
		}

		$response = self::remote_get_with_retry(
			'https://api.github.com/repos/' . self::REPO . '/releases/latest',
			array(
				'headers' => array( 'Accept' => 'application/vnd.github+json' ),
				'timeout' => self::REQUEST_TIMEOUT,
			)
		);
		if ( is_wp_error( $response ) ) {
			self::remember_check_error( 'No se pudo contactar con GitHub para comprobar actualizaciones: ' . $response->get_error_message() . '. Esto suele deberse a que tu hosting corta las conexiones salientes hacia servicios externos.' );
			set_transient( self::CACHE_KEY, '', 15 * MINUTE_IN_SECONDS ); // Fallo: reintenta pronto, no en 6h.
			return false;
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			self::remember_check_error( 'GitHub respondió con un error al comprobar actualizaciones (HTTP ' . (int) wp_remote_retrieve_response_code( $response ) . ').' );
			set_transient( self::CACHE_KEY, '', 15 * MINUTE_IN_SECONDS ); // Fallo: reintenta pronto, no en 6h.
			return false;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['tag_name'] ) ) {
			self::remember_check_error( 'GitHub respondió, pero sin datos de versión reconocibles.' );
			set_transient( self::CACHE_KEY, '', 15 * MINUTE_IN_SECONDS ); // Fallo: reintenta pronto, no en 6h.
			return false;
		}
		delete_transient( self::CHECK_ERROR_KEY );

		$version = trim( ltrim( (string) $data['tag_name'], 'vV' ) );

		// El .zip del plugin se sube como un archivo más dentro del propio
		// repositorio (en /dist), en vez de como "asset" adjunto al release.
		// raw.githubusercontent.com sirve ese archivo tal cual, sin pasar
		// por el sistema de adjuntos de GitHub.
		$zip_url = 'https://raw.githubusercontent.com/' . self::REPO . '/' . rawurlencode( (string) $data['tag_name'] ) . '/dist/scangeo-fix.zip';

		$result = array(
			'version'   => $version,
			'zip_url'   => $zip_url,
			'notes_url' => isset( $data['html_url'] ) ? $data['html_url'] : '',
			'body'      => isset( $data['body'] ) ? $data['body'] : '',
		);
		set_transient( self::CACHE_KEY, $result, 6 * HOUR_IN_SECONDS );
		return $result;
	}

	/**
	 * Consulta el listado completo de releases (no solo el último) para
	 * construir un registro de cambios con varias versiones, como el que
	 * enseñan los plugins de wordpress.org. Caché de 6 horas.
	 */
	private static function get_all_releases() {
		if ( false !== strpos( self::REPO, 'TU-USUARIO' ) ) {
			return array();
		}
		$cached = get_transient( self::CACHE_KEY_ALL );
		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : array();
		}
		$response = self::remote_get_with_retry(
			'https://api.github.com/repos/' . self::REPO . '/releases?per_page=15',
			array(
				'headers' => array( 'Accept' => 'application/vnd.github+json' ),
				'timeout' => self::REQUEST_TIMEOUT,
			)
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			set_transient( self::CACHE_KEY_ALL, array(), 6 * HOUR_IN_SECONDS );
			return array();
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) ) {
			set_transient( self::CACHE_KEY_ALL, array(), 6 * HOUR_IN_SECONDS );
			return array();
		}
		$releases = array();
		foreach ( $data as $item ) {
			if ( empty( $item['tag_name'] ) ) {
				continue;
			}
			$releases[] = array(
				'version' => trim( ltrim( (string) $item['tag_name'], 'vV' ) ),
				'date'    => isset( $item['published_at'] ) ? $item['published_at'] : '',
				'body'    => isset( $item['body'] ) ? $item['body'] : '',
			);
		}
		set_transient( self::CACHE_KEY_ALL, $releases, 6 * HOUR_IN_SECONDS );
		return $releases;
	}

	/** Construye el HTML del registro de cambios a partir de varias versiones. */
	private static function build_changelog_html() {
		$releases = self::get_all_releases();
		if ( empty( $releases ) ) {
			return 'Sin notas de la versión.';
		}
		$html = '';
		foreach ( $releases as $r ) {
			$date  = $r['date'] ? mysql2date( 'd/m/Y', $r['date'] ) : '';
			$html .= '<h4>Versión ' . esc_html( $r['version'] ) . ( $date ? ' — ' . esc_html( $date ) : '' ) . '</h4>';
			$html .= $r['body'] ? wpautop( wp_kses_post( $r['body'] ) ) : '<p><em>Sin notas.</em></p>';
		}
		return $html;
	}

	/** Engancha la versión de GitHub al comprobador de actualizaciones de WordPress. */
	public static function check_update( $transient ) {
		if ( empty( $transient ) || ! is_object( $transient ) ) {
			return $transient;
		}
		$release = self::get_latest_release();
		if ( ! $release || empty( $release['zip_url'] ) ) {
			// No se pudo comprobar (fallo de red, límite de peticiones de
			// GitHub...). Por seguridad, se retira cualquier aviso de
			// actualización que pudiera haber quedado de una comprobación
			// anterior, en vez de dejarlo "colgado" indefinidamente: es
			// preferible no avisar por un momento a mostrar un aviso falso.
			foreach ( self::supported_plugin_files() as $plugin_file ) {
				unset( $transient->response[ $plugin_file ] );
			}
			return $transient;
		}
		$installed = self::installed_version();
		$latest    = trim( (string) $release['version'] );
		if ( version_compare( $latest, $installed, '>' ) ) {
			$icon_url = defined( 'SCANGEO_FIXER_URL' ) ? SCANGEO_FIXER_URL . 'assets/icon.png' : '';
			// OJO: tiene que ser current_plugin_file(), no solo PLUGIN_FILE/LEGACY_PLUGIN_FILE.
			// get_plugin_updates() (wp-admin/includes/update.php) solo muestra una
			// actualizacion si la clave coincide EXACTAMENTE con una de las rutas que
			// devuelve get_plugins() para los plugins realmente instalados. Si el
			// sitio quedo instalado en una carpeta con el numero de version en el
			// nombre (scangeo-fix-2.2.0, herencia de actualizaciones manuales
			// anteriores), ni PLUGIN_FILE ('scangeo-fix/...') ni LEGACY_PLUGIN_FILE
			// ('scangeo-fixer/...') existen, asi que WordPress descarta el aviso en
			// silencio aunque el aviso interno del plugin sí lo detecte bien.
			$installed_file = self::current_plugin_file();
			$transient->response[ $installed_file ] = (object) array(
				'slug'        => self::SLUG,
				'plugin'      => $installed_file,
				'new_version' => $latest,
				'url'         => $release['notes_url'],
				'package'     => $release['zip_url'],
				'tested'      => get_bloginfo( 'version' ),
				'icons'       => $icon_url ? array( '1x' => $icon_url, '2x' => $icon_url, 'default' => $icon_url ) : array(),
			);
		} else {
			// Muy importante: si NO hay versión más nueva, hay que quitar
			// explícitamente cualquier entrada previa para este plugin
			// (si no, un aviso de una comprobación anterior podría quedarse
			// "pegado" en el transient aunque ya no aplique).
			foreach ( self::supported_plugin_files() as $plugin_file ) {
				unset( $transient->response[ $plugin_file ] );
			}
			if ( ! isset( $transient->no_update ) ) {
				$transient->no_update = array();
			}
			$installed_file = self::current_plugin_file();
			$transient->no_update[ $installed_file ] = (object) array(
				'slug'        => self::SLUG,
				'plugin'      => $installed_file,
				'new_version' => $installed,
				'url'         => $release['notes_url'],
				'package'     => '',
			);
		}
		return $transient;
	}

	/** Fuerza y persiste la comprobación para Escritorio > Actualizaciones. */
	public static function force_update_check() {
		delete_transient( self::CACHE_KEY );
		delete_transient( self::CACHE_KEY_ALL );
		delete_site_transient( 'update_plugins' );

		if ( ! function_exists( 'wp_update_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
		}
		wp_update_plugins();

		$transient = get_site_transient( 'update_plugins' );
		if ( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		$transient = self::check_update( $transient );
		set_site_transient( 'update_plugins', $transient );
		return $transient;
	}

	/** Rellena la ventana de "Ver detalles de la versión" en el listado de plugins. */
	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$release = self::get_latest_release();
		if ( ! $release ) {
			return $result;
		}
		$icon_url   = defined( 'SCANGEO_FIXER_URL' ) ? SCANGEO_FIXER_URL . 'assets/icon.png' : '';
		$banner_low = defined( 'SCANGEO_FIXER_URL' ) ? SCANGEO_FIXER_URL . 'assets/banner-772x250.png' : '';
		$banner_hi  = defined( 'SCANGEO_FIXER_URL' ) ? SCANGEO_FIXER_URL . 'assets/banner-1544x500.png' : '';

		$description = '<p><strong>scanGEO Fixer</strong> lee el informe .md exportado desde scanGEO.app (con su bloque de datos de automatización), muestra tu puntuación por categoría (técnico, contenido, GEO, off-page) y repara los fallos detectados directamente desde tu WordPress:</p>'
			. '<ul>'
			. '<li>✔ Automáticamente cuando es seguro: canonical, viewport, lang, Open Graph, JSON-LD, robots.txt, sitemap, llms.txt, alt de imágenes.</li>'
			. '<li>📝 Con una propuesta de IA que revisas y apruebas cuando toca contenido: meta descriptions, títulos, FAQ, respuesta directa, enlaces internos, ampliar contenido corto.</li>'
			. '<li>✋ O te explica exactamente qué hacer a mano cuando no se puede automatizar (por ejemplo, si ya lo gestiona Yoast o Rank Math).</li>'
			. '</ul>'
			. '<p>Cualquier cambio aplicado se puede deshacer con un clic, y el plugin guarda el histórico de puntuaciones entre informes para ver la evolución de tu web con el tiempo.</p>';

		$installation = '<ol>'
			. '<li>Sube la carpeta <code>scangeo-fix</code> a <code>/wp-content/plugins/</code>, o instala el .zip desde Plugins → Añadir nuevo → Subir plugin.</li>'
			. '<li>Activa el plugin.</li>'
			. '<li>(Opcional, recomendado) En scanGEO Fixer → Ajustes, añade tu clave de IA (Anthropic u OpenAI) para las propuestas de contenido y el resumen en palabras sencillas.</li>'
			. '<li>Ve a scanGEO Fixer, sube el informe .md exportado desde scanGEO.app y pulsa "Reparar todo".</li>'
			. '</ol>';

		return (object) array(
			'name'          => 'scanGEO Fixer',
			'slug'          => self::SLUG,
			'version'       => $release['version'],
			'author'        => '<a href="https://scangeo.app">scanGEO.app</a>',
			'homepage'      => $release['notes_url'],
			'tested'        => get_bloginfo( 'version' ),
			'requires'      => '5.8',
			'requires_php'  => '7.4',
			'last_updated'  => isset( $release['date'] ) ? $release['date'] : '',
			'sections'      => array(
				'description'  => $description,
				'installation' => $installation,
				'changelog'    => self::build_changelog_html(),
			),
			'download_link' => $release['zip_url'],
			'icons'         => $icon_url ? array( '1x' => $icon_url, '2x' => $icon_url, 'default' => $icon_url ) : array(),
			'banners'       => ( $banner_low || $banner_hi ) ? array( 'low' => $banner_low, 'high' => $banner_hi ) : array(),
		);
	}

	/**
	 * Si se usa el zip automático de GitHub (sin adjuntar uno propio), la
	 * carpeta interna tiene un nombre distinto (usuario-repo-hash). Esto la
	 * renombra a "scangeo-fix" para que WordPress lo trate como una
	 * actualización del mismo plugin en vez de instalar uno nuevo aparte.
	 */
	public static function fix_folder_name( $source, $remote_source, $upgrader, $hook_extra ) {
		global $wp_filesystem;
		if ( empty( $hook_extra['plugin'] ) || ( self::PLUGIN_FILE !== $hook_extra['plugin'] && self::LEGACY_PLUGIN_FILE !== $hook_extra['plugin'] ) ) {
			return $source;
		}
		$desired = trailingslashit( $remote_source ) . self::SLUG . '/';
		if ( $source !== $desired && $wp_filesystem && $wp_filesystem->move( $source, $desired, true ) ) {
			return $desired;
		}
		return $source;
	}
}
